<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'booktool_importhtml', language 'de', version '4.5'.
 *
 * @package     booktool_importhtml
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['doimport'] = 'Import';
$string['errornochapters'] = 'Keine Kapitel in der Datei gefunden';
$string['import'] = 'Kapitel importieren';
$string['importhtml:import'] = 'Kapitel importieren';
$string['importing'] = 'Import läuft ...';
$string['importingchapters'] = 'Kapitel ins Buch importieren';
$string['pluginname'] = 'Kapitelimport';
$string['privacy:metadata'] = 'Das Plugin \'Buch Kapitelimport\' speichert keine personenbezogenen Daten.';
$string['relinking'] = 'Neuverlinkung läuft ...';
$string['type'] = 'Typ';
$string['typeonefile'] = 'Überschriften trennen HTML-Datei in Kapitel';
$string['typezipdirs'] = 'Jedes Verzeichnis ist ein Kapitel';
$string['typezipfiles'] = 'Jede HTML-Datei ist ein Kapitel';
$string['ziparchive'] = 'ZIP-Datei';
$string['ziparchive_help'] = 'Wählen Sie eine ZIP-Datei aus, die alle HTML- und Multimedia-Dateien enthält. Unterkapitel werden erzeugt, wenn die Datei- oder Verzeichnisnamen mit "_sub" enden.';
