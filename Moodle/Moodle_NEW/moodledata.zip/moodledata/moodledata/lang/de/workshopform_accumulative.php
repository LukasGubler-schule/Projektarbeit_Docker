<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'workshopform_accumulative', language 'de', version '4.5'.
 *
 * @package     workshopform_accumulative
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['absent'] = 'Abwesend';
$string['addmoredimensions'] = '{$a} weitere Kriterien';
$string['correct'] = 'Richtig';
$string['dimensioncommentfor'] = 'Kommentar für {$a}';
$string['dimensiondescription'] = 'Beschreibung';
$string['dimensiongradefor'] = 'Bewertung für {$a}';
$string['dimensionmaxgrade'] = 'Beste Punktzahl oder Auswahl Bewertungstexte';
$string['dimensionnumber'] = 'Kriterium {$a}';
$string['dimensionweight'] = 'Gewichtung';
$string['excellent'] = 'Exzellent';
$string['good'] = 'Gut';
$string['incorrect'] = 'Falsch';
$string['mustchoosegrade'] = 'Sie müssen eine Bewertung für dieses Kriterium vergeben.';
$string['pluginname'] = 'Aufsummierte Bewertung';
$string['poor'] = 'Schlecht';
$string['present'] = 'Anwesend';
$string['privacy:metadata'] = 'Das Plugin zur aufsummierten Bewertung speichert keine persönlichen Daten. Die aktuellen Daten, wer wem zugewiesen wird, um Lösungen zu bewerten, werden in der Aktivität \'gegenseitige Beurteilung\' gespeichert und an die exportierten Aufgaben angehängt.';
$string['scalename0'] = 'Ja/Nein (2 Optionen)';
$string['scalename1'] = 'Anwesend/Abwesend (2 Optionen)';
$string['scalename2'] = 'Richtig/Falsch (2 Optionen)';
$string['scalename3'] = 'Gut/Schlecht (3 Optionen)';
$string['scalename4'] = 'Sehr gut/Sehr schlecht (4 Optionen)';
$string['scalename5'] = 'Sehr gut/Sehr schlecht (5 Optionen)';
$string['scalename6'] = 'Sehr gut/Sehr schlecht (7 Optionen)';
$string['verypoor'] = 'Sehr schlecht';
