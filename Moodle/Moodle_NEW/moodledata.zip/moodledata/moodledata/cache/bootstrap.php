<?php
// ********** This file is generated DO NOT EDIT **********
$CFG->siteidentifier = '7el5H7Ae2MWqeu9LYdFnOJ8nLStZVRBflocalhost';
$CFG->bootstraphash = 'ca97b3f056683feb16d1867bff91e76f';
// Only if the file is not stale and has not been defined.
if ($CFG->bootstraphash === hash_local_config_cache() && !defined('SYSCONTEXTID')) {
    define('SYSCONTEXTID', 1);
}
