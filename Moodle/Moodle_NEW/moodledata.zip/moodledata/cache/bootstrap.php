<?php
// ********** This file is generated DO NOT EDIT **********
$CFG->siteidentifier = '7el5H7Ae2MWqeu9LYdFnOJ8nLStZVRBflocalhost';
$CFG->bootstraphash = 'e85b2d27a64f5c832054bc0246c1f24f';
// Only if the file is not stale and has not been defined.
if ($CFG->bootstraphash === hash_local_config_cache() && !defined('SYSCONTEXTID')) {
    define('SYSCONTEXTID', 1);
}
